from typing import List, Dict

# Master questions list
# Think of this as our question bank - each question is a conversation spark!
QUESTIONS: List[Dict[str, str]] = [
    # ==================== LIFE CATEGORY ====================
    # Questions about personal growth, goals, and lifestyle choices
    {
        "id": "life_001",
        "text": "What’s a book you’ve read recently that you’d enthusiastically recommend, and what about it grabbed you?",
        "category": "life",
    },
    {
        "id": "life_002",
        "text": "What is something you’re almost incapable of turning down, no matter when it’s offered?",
        "category": "life",
    },
    {
        "id": "life_003",
        "text": "What is a totally ordinary everyday activity that would feel completely out of character for you to do regularly?",
        "category": "life",
    },
    {
        "id": "life_004",
        "text": "Which Netflix series did you race through in record time, and what made it so binge-worthy for you?",
        "category": "life",
    },
    {
        "id": "life_005",
        "text": "What’s the best or most meaningful gift you’ve ever received, and why did it matter so much?",
        "category": "life",
    },
    {
        "id": "life_006",
        "text": "Who in your life inspires you to grow into a better version of yourself, and how do they influence you?",
        "category": "life",
    },
    {
        "id": "life_007",
        "text": "Describe what your first 30 minutes after waking up usually look like on a typical day.",
        "category": "life",
    },
    {
        "id": "life_008",
        "text": "How do you most naturally show affection, and what kinds of gestures make you feel truly cared for?",
        "category": "life",
    },
    {
        "id": "life_009",
        "text": "What activity makes time completely disappear for you because you’re so absorbed in it?",
        "category": "life",
    },
    {
        "id": "life_010",
        "text": "What family tradition do you most want to keep alive for future generations, and why is it important to you?",
        "category": "life",
    },
    {
        "id": "life_011",
        "text": "Which personal milestone or achievement are you proudest of, and what did it take to get there?",
        "category": "life",
    },
    {
        "id": "life_012",
        "text": "If everyone had a visible stat floating above their head, what metric would you want to see and why?",
        "category": "life",
    },
    {
        "id": "life_013",
        "text": "Which board game do you enjoy the most, and what do you like about the way it plays?",
        "category": "life",
    },
    {
        "id": "life_014",
        "text": "What sport or hobby did you try as a kid and totally flop at, and how do you feel about it now?",
        "category": "life",
    },
    {
        "id": "life_015",
        "text": "If you could safely experience any natural disaster as an observer, which would you choose and what draws you to it?",
        "category": "life",
    },
    {
        "id": "life_016",
        "text": "Describe a scent that instantly transports you to a specific memory—what memory does it bring back?",
        "category": "life",
    },
    {
        "id": "life_017",
        "text": "What’s the largest or most expensive thing you’ve ever bought for yourself, and how did you feel afterward?",
        "category": "life",
    },
    {
        "id": "life_018",
        "text": "Tell me about a small act of kindness you witnessed that left a lasting impression on you.",
        "category": "life",
    },
    {
        "id": "life_019",
        "text": "Who had the biggest influence on you while you were growing up, and in what ways did they shape you?",
        "category": "life",
    },
    {
        "id": "life_020",
        "text": "Name someone you deeply admire and explain what you respect most about them.",
        "category": "life",
    },
    {
        "id": "life_021",
        "text": "What belief or important truth do you hold that most people around you don’t agree with?",
        "category": "life",
    },
    {
        "id": "life_022",
        "text": "What did you used to believe about work or your career that you now see very differently?",
        "category": "life",
    },
    {
        "id": "life_023",
        "text": "What is a skill you learned when you were young that you still use regularly today?",
        "category": "life",
    },
    {
        "id": "life_024",
        "text": "What was your favorite subject in school, and what made it so enjoyable for you?",
        "category": "life",
    },
    {
        "id": "life_025",
        "text": "When you were a kid, what did you imagine you would be when you grew up?",
        "category": "life",
    },

    # ==================== RANDOM CATEGORY ====================
    # Fun, lighthearted questions to break the ice
    {
        "id": "random_001",
        "text": "If a zombie apocalypse suddenly hit, which three people would you want on your survival team, and why them?",
        "category": "random",
    },
    {
        "id": "random_002",
        "text": "If you were a rapper, what stage name would you pick for yourself?",
        "category": "random",
    },
    {
        "id": "random_003",
        "text": "When you play Monopoly, which game piece do you usually grab first, and why that one?",
        "category": "random",
    },
    {
        "id": "random_004",
        "text": "Which celebrity’s life or news do you keep up with a little more closely than you’d care to admit?",
        "category": "random",
    },
    {
        "id": "random_005",
        "text": "What’s a story about you that you hope your kids or future family will keep retelling for years?",
        "category": "random",
    },
    {
        "id": "random_006",
        "text": "At a café, what’s your go-to drink order?",
        "category": "random",
    },
    {
        "id": "random_007",
        "text": "What’s the most recent random thing that made you literally laugh out loud?",
        "category": "random",
    },
    {
        "id": "random_008",
        "text": "Do you have a favorite quote or saying? What is it, and why does it stick with you?",
        "category": "random",
    },
    {
        "id": "random_009",
        "text": "What’s the most interesting thing you’ve learned recently from a podcast or YouTube video?",
        "category": "random",
    },
    {
        "id": "random_010",
        "text": "Can you think of a tiny, seemingly unimportant decision that ended up having a big impact on your life?",
        "category": "random",
    },
    {
        "id": "random_011",
        "text": "Have you ever met someone famous? Who was it, and what was that interaction like?",
        "category": "random",
    },
    {
        "id": "random_012",
        "text": "What small act of rebellion or rule-bending do you indulge in on a regular basis?",
        "category": "random",
    },
    {
        "id": "random_013",
        "text": "How have AI tools and chatbots changed the way you live or work day to day?",
        "category": "random",
    },
    {
        "id": "random_014",
        "text": "If you could choose any fictional character to be your best friend, who would you pick and why?",
        "category": "random",
    },
    {
        "id": "random_015",
        "text": "What’s the most fascinating place you’ve ever visited, and what made it stand out to you?",
        "category": "random",
    },
    {
        "id": "random_016",
        "text": "Are you more of a morning person or a night owl, and how does that show up in your routine?",
        "category": "random",
    },
    {
        "id": "random_017",
        "text": "What childhood dream or goal have you never really let go of?",
        "category": "random",
    },
    {
        "id": "random_018",
        "text": "What’s something you genuinely like that other people often find strange or a little creepy?",
        "category": "random",
    },
    {
        "id": "random_019",
        "text": "If money were completely irrelevant, what would your dream job or role look like?",
        "category": "random",
    },
    {
        "id": "random_020",
        "text": "Has anyone ever told you that you resemble a particular celebrity? Who do people say you look like?",
        "category": "random",
    },
    {
        "id": "random_021",
        "text": "If you had to relive the same day on repeat for the rest of your life, which day would you choose and why?",
        "category": "random",
    },
    {
        "id": "random_022",
        "text": "What’s a purchase under $10 that you use all the time or got an amazing amount of value from?",
        "category": "random",
    },
    {
        "id": "random_023",
        "text": "What’s something about you that usually surprises people when they first find out?",
        "category": "random",
    },
    {
        "id": "random_024",
        "text": "If a movie were made about your life, which actor would you want to play you?",
        "category": "random",
    },
    {
        "id": "random_025",
        "text": "When was the last time you felt left out or excluded, and what was going on?",
        "category": "random",
    },

    # ==================== DEEP CATEGORY ====================
    # Philosophical and meaningful conversation starters
    {
        "id": "deep_001",
        "text": "What stereotype about people like you do you think you actually fit pretty well?",
        "category": "deep",
    },
    {
        "id": "deep_002",
        "text": "When your life is over, what would you most like people to remember you for?",
        "category": "deep",
    },
    {
        "id": "deep_003",
        "text": "Which part of your childhood do you look back on with the most fondness, and why?",
        "category": "deep",
    },
    {
        "id": "deep_004",
        "text": "In what ways do you sometimes hold yourself back or get in the way of your own success?",
        "category": "deep",
    },
    {
        "id": "deep_005",
        "text": "In which area of your life do you wish you felt more confident, and what difference would that make?",
        "category": "deep",
    },
    {
        "id": "deep_006",
        "text": "Looking back, what’s something you wish you had done when you were younger but didn’t?",
        "category": "deep",
    },
    {
        "id": "deep_007",
        "text": "What personal rules or standards do you hold yourself to that you almost never break?",
        "category": "deep",
    },
    {
        "id": "deep_008",
        "text": "Tell the story of a bridge you burned—a relationship or opportunity you walked away from—and why you did it.",
        "category": "deep",
    },
    {
        "id": "deep_009",
        "text": "What worries you most about the world the next generation is inheriting?",
        "category": "deep",
    },
    {
        "id": "deep_010",
        "text": "What’s one thing you’ve done that you wish you could go back in time and undo?",
        "category": "deep",
    },
    {
        "id": "deep_011",
        "text": "What’s the boldest or most daring thing you’ve ever done?",
        "category": "deep",
    },
    {
        "id": "deep_012",
        "text": "Describe a chance encounter or random meeting that ended up changing your life.",
        "category": "deep",
    },
    {
        "id": "deep_013",
        "text": "What are the top three things on your bucket list right now?",
        "category": "deep",
    },
    {
        "id": "deep_014",
        "text": "Which moments or decisions stand out as major turning points in your life story?",
        "category": "deep",
    },
    {
        "id": "deep_015",
        "text": "What do you believe in even though you don’t really have solid proof for it?",
        "category": "deep",
    },
    {
        "id": "deep_016",
        "text": "How has social media changed the way you think about friendship and connection?",
        "category": "deep",
    },
    {
        "id": "deep_017",
        "text": "What is something you’re pretty certain you’ll never experience in your life, and why?",
        "category": "deep",
    },
    {
        "id": "deep_018",
        "text": "When you imagine the next 10 years, what are you most looking forward to?",
        "category": "deep",
    },
    {
        "id": "deep_019",
        "text": "What is one thing you think everyone should do at least once in their lifetime?",
        "category": "deep",
    },
    {
        "id": "deep_020",
        "text": "What patterns or mistakes do you catch yourself repeating over and over again?",
        "category": "deep",
    },
    {
        "id": "deep_021",
        "text": "What is the hardest decision you’ve ever had to make, and how did you arrive at your choice?",
        "category": "deep",
    },
    {
        "id": "deep_022",
        "text": "What topic do you find hardest to talk about with your family or close friends, and why is it so difficult?",
        "category": "deep",
    },
    {
        "id": "deep_023",
        "text": "What do people often misunderstand or get wrong about you at first glance?",
        "category": "deep",
    },
    {
        "id": "deep_024",
        "text": "What’s something about the way you were raised that you don’t fully agree with now?",
        "category": "deep",
    },
    {
        "id": "deep_025",
        "text": "When was the last time you cried, and what brought those tears on?",
        "category": "deep",
    },

    # ==================== EXPERIENCES CATEGORY ====================
    # Questions about stories, memories, and adventures
    {
        "id": "experiences_001",
        "text": "Tell me about an opportunity for love or money that you turned down—do you regret that choice now?",
        "category": "experiences",
    },
    {
        "id": "experiences_002",
        "text": "What’s the most unforgettable or wild party you’ve ever been to, and what made it so memorable?",
        "category": "experiences",
    },
    {
        "id": "experiences_003",
        "text": "How old were you when you met your best friend, and what first brought you together?",
        "category": "experiences",
    },
    {
        "id": "experiences_004",
        "text": "What’s something you did as a child that your family still loves to tell stories about?",
        "category": "experiences",
    },
    {
        "id": "experiences_005",
        "text": "What’s an unusual or unexpected skill you have, and how did you pick it up?",
        "category": "experiences",
    },
    {
        "id": "experiences_006",
        "text": "Share an embarrassing or awkward moment that happened to you on a date.",
        "category": "experiences",
    },
    {
        "id": "experiences_007",
        "text": "How has the idea of “cancel culture” influenced the way you behave or speak online?",
        "category": "experiences",
    },
    {
        "id": "experiences_008",
        "text": "What was your very first car, and who ended up paying for it?",
        "category": "experiences",
    },
    {
        "id": "experiences_009",
        "text": "What’s the first thing you clearly remember buying with your own money?",
        "category": "experiences",
    },
    {
        "id": "experiences_010",
        "text": "If money were no object at all, what kind of car would you choose to drive?",
        "category": "experiences",
    },
    {
        "id": "experiences_011",
        "text": "What was the first concert you ever went to, and how did it feel to be there?",
        "category": "experiences",
    },
    {
        "id": "experiences_012",
        "text": "What’s something about you that people usually find surprising or least expect?",
        "category": "experiences",
    },
    {
        "id": "experiences_013",
        "text": "On a typical Friday night, where are you most likely to be and what are you usually doing?",
        "category": "experiences",
    },
    {
        "id": "experiences_014",
        "text": "What was your first job, and what’s one lesson you took away from it?",
        "category": "experiences",
    },
    {
        "id": "experiences_015",
        "text": "What’s a compliment you received that genuinely changed how you see yourself?",
        "category": "experiences",
    },
    {
        "id": "experiences_016",
        "text": "What’s the best date you’ve ever been on, and what made it stand out?",
        "category": "experiences",
    },
    {
        "id": "experiences_017",
        "text": "What bad habit do you wish you could finally quit?",
        "category": "experiences",
    },
    {
        "id": "experiences_018",
        "text": "What state or country do you miss the most or really want to go back to, and why?",
        "category": "experiences",
    },
    {
        "id": "experiences_019",
        "text": "What’s the most unexpected or surprising thing that has ever happened to you on a date?",
        "category": "experiences",
    },
    {
        "id": "experiences_020",
        "text": "What’s something you genuinely appreciate about the opposite gender?",
        "category": "experiences",
    },
    {
        "id": "experiences_021",
        "text": "What’s something you’ve done once that you’re sure you would never do again?",
        "category": "experiences",
    },
    {
        "id": "experiences_022",
        "text": "What product do you love so much that you’d happily buy it again and again?",
        "category": "experiences",
    },
    {
        "id": "experiences_023",
        "text": "What’s your most unusual or oddly specific pet peeve?",
        "category": "experiences",
    },
    {
        "id": "experiences_024",
        "text": "What is the best piece of advice you’ve ever received, and why has it stayed with you?",
        "category": "experiences",
    },
    {
        "id": "experiences_025",
        "text": "What’s the worst haircut you’ve ever had, and what exactly went wrong?",
        "category": "experiences",
    },
]

# Quick stats for verification
QUESTION_COUNT = len(QUESTIONS)
CATEGORIES = list(set(q["category"] for q in QUESTIONS))

# Validation function - makes sure our data is clean
def validate_questions() -> bool:
    """
    Validates the questions data structure.

    Returns:
        True if all questions are valid, False otherwise

    Checks:
    - Each question has required fields (id, text, category)
    - IDs are unique
    - Categories match expected values
    """
    seen_ids = set()
    valid_categories = {"life", "random", "deep", "experiences"}

    for question in QUESTIONS:
        # Check required fields exist
        if not all(key in question for key in ["id", "text", "category"]):
            print(f"❌ Question missing required fields: {question}")
            return False

        # Check for duplicate IDs
        if question["id"] in seen_ids:
            print(f"❌ Duplicate question ID found: {question['id']}")
            return False
        seen_ids.add(question["id"])

        # Check category is valid
        if question["category"] not in valid_categories:
            print(f"❌ Invalid category '{question['category']}' for question: {question['id']}")
            return False

    print(f"✅ All {QUESTION_COUNT} questions validated successfully!")
    print(f"📊 Categories: {', '.join(sorted(CATEGORIES))}")
    return True


if __name__ == "__main__":
    # Run validation when file is executed directly
    # Usage: python questions_data.py
    print("🔍 Validating questions dataset...")
    validate_questions()
    print(f"\n📚 Total questions: {QUESTION_COUNT}")
    for category in sorted(CATEGORIES):
        count = sum(1 for q in QUESTIONS if q["category"] == category)
        print(f"   - {category}: {count} questions")
